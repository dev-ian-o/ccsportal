<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/variables.php"); ?>
<?php teacher_confirm_logged_in()?> 
<?php

// if(isset($_POST['userid']))
// {

// 	if($_POST['user'] == "teacher"){
// 		$id_no = $_SESSION['id_no'];
// 		$id = $_SESSION['teacher_id'];	//EMPLOYEE NUM/ STUD. NO
// 		if(($new == $retype) && (isset($_POST['new'])) && ($_POST['retype']))
// 		{
// 			change_password($new,$id,$id_no,$_POST['user']);
// 			echo "<script>$('#form_pass').before('<div id=\"formmessage\"><p>Your password is being changed.</p></div>'); $('#form_pass').hide();</script>";			
// 		}
// 	}
// 	else if($_POST['user'] == "student"){
// 		$id_no = $_SESSION['id_no'];
// 		$id = $_SESSION['user_id'];	//EMPLOYEE NUM/ STUD. NO

// 		if(($new == $retype) && (isset($_POST['new'])) && ($_POST['retype']))
// 		{
// 			change_password($new,$id,$id_no,$_POST['user']);
// 			echo "<script>$('#form_pass').before('<div id=\"formmessage\"><p>Your password is being changed.</p></div>'); $('#form_pass').hide();</script>";			
// 		}
// 	}

// }

if($_REQUEST['old'] && isset($_POST['old']))
{
		
	// $query = "SELECT id_student FROM tblstudent WHERE password = SHA('$old') AND student_no = '$id_no'";
	 //    $result = @mysql_query($query);
	 //    $row = mysql_fetch_array($result); 
		$id_no = $_SESSION['id_no'];	
		$query = "SELECT password
				  FROM tblteacher 
				  WHERE employee_no = '$id_no'";

	    $result = @mysql_query($query);
	    $row = mysql_fetch_array($result,MYSQL_NUM);
	    if(rtnDecrypt($row[0]) === $old)
		{
			$row = true;
		}
		else {$row = false;}

	    if (!($row)){
	    	echo "<script>$('#lbloldpass').after('<center><label class=\"error\">Invalid old password.</label></center>');</script>"; 
	    	$noError = false;
	    }	
		if(($new == $retype) && (isset($_POST['new'])) && ($_POST['retype']) && ($row))
		{	

			$id_no = $_SESSION['id_no'];
			$id = $_SESSION['teacher_id'];	//EMPLOYEE NUM/ STUD. NO
			change_password($new,$id,$id_no,$_SESSION['level_user']);
			echo "<script>$('#form_pass').before('<div id=\"formmessage\"><p>Your password is being changed.</p></div>'); $('#form_pass').hide();</script>";			
			echo "<script>setTimeout(function () {
				window.location.href= 'settings.php';
			},3000);</script>";
		}
}

if($_REQUEST['password'] && $_REQUEST['username'])
{
	 
}

?>


